package com.stockcharting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StockChartingConfirmUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(StockChartingConfirmUserApplication.class, args);
	}

}
